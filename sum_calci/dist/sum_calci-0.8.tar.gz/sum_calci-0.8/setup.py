from setuptools import setup, find_packages

setup(name='sum_calci',
      version='0.8',
      scripts=['__init__.py'],
      packages=find_packages()
      )